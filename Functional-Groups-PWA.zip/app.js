
fetch('data/functional_groups.json')
  .then(response => response.json())
  .then(groups => {
    const container = document.getElementById('groups-container');
    const quizContainer = document.getElementById('quiz-container');

    // Display functional group cards
    groups.forEach(group => {
      const card = document.createElement('div');
      card.className = 'group-card';
      card.innerHTML = `
        <img src="${group.image}" alt="${group.name}">
        <h3>${group.name}</h3>
        <p><strong>Formula:</strong> ${group.formula}</p>
        <p><strong>Examples:</strong> ${group.examples.join(', ')}</p>
        <p><strong>Properties:</strong> ${group.properties}</p>
      `;
      container.appendChild(card);
    });

    // Matching game setup
    const shuffledGroups = groups.sort(() => Math.random() - 0.5);
    const draggableDiv = document.createElement('div');
    draggableDiv.innerHTML = '<h2>Matching Game: Drag the names to correct structures</h2>';
    quizContainer.appendChild(draggableDiv);

    const namesContainer = document.createElement('div');
    const imagesContainer = document.createElement('div');
    namesContainer.id = 'names';
    imagesContainer.id = 'images';

    shuffledGroups.forEach(group => {
      const nameDiv = document.createElement('div');
      nameDiv.className = 'draggable';
      nameDiv.draggable = true;
      nameDiv.innerText = group.name;
      nameDiv.dataset.name = group.name;

      nameDiv.addEventListener('dragstart', e => e.dataTransfer.setData('text', e.target.dataset.name));

      namesContainer.appendChild(nameDiv);

      const imageDiv = document.createElement('div');
      imageDiv.className = 'dropzone';
      imageDiv.dataset.name = group.name;
      const img = document.createElement('img');
      img.src = group.image;
      img.style.maxWidth = '100px';
      imageDiv.appendChild(img);

      imageDiv.addEventListener('dragover', e => e.preventDefault());
      imageDiv.addEventListener('drop', e => {
        const draggedName = e.dataTransfer.getData('text');
        if(draggedName === e.target.dataset.name || draggedName === e.target.closest('.dropzone').dataset.name){
          alert('Correct!');
        } else {
          alert('Try again!');
        }
      });

      imagesContainer.appendChild(imageDiv);
    });

    quizContainer.appendChild(namesContainer);
    quizContainer.appendChild(imagesContainer);
  });
